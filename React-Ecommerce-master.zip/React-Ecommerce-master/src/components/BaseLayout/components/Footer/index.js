//Dependencies
import React from 'react';
//Internals
import './index.css';

const Footer = () => (
  <div className="footer">
    <p>© 2017 Copyright Lydia Hallie</p>
  </div>
)

export default Footer;
